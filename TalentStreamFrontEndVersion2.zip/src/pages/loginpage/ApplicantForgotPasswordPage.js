import React from 'react'
import Nav from '../../components/common/Nav';
import Footer from '../../components/common/Footer';
import ApplicantForgotPassword from '../../components/applicantcomponents/ApplicantForgotPassword';


function RecruiterForgotPasswordPage() {
  return (
    <div>
     <Nav />
    <ApplicantForgotPassword />
    <Footer />
    </div>
  )
}

export default RecruiterForgotPasswordPage;