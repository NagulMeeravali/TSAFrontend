
import axios from 'axios';
export const apiUrl = 'http://localhost:8081';

//export const apiUrl = 'https://talentstreambackendversion2.onrender.com';


const ApplicantAPIService = {

    


}
export default ApplicantAPIService;
