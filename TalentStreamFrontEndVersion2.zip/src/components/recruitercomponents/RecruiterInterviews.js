import React from 'react'

function RecruiterInterviews() {
  return (
    <div>RecruiterInterviews</div>
  )
}

export default RecruiterInterviews;