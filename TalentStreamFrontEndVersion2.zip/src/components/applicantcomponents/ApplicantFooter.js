import React from 'react'

function ApplicantFooter() {
  return (
    <div>

<section class="flat-dashboard-bottom">
      <div class="themes-container">
        <div class="row">
          <div class="col-lg-12 col-md-12 ">
            <h5 class="center">©2023 TekWorks. All Rights Reserved.</h5>
          </div>
        </div>
      </div>
    </section>


    </div>
  )
}

export default ApplicantFooter;