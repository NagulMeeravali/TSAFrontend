import React from 'react'

export default function ApplicantJobAlerts() {
  return (
    <div>

<div class="dashboard__content">
    <section class="page-title-dashboard">
      <div class="themes-container">
        <div class="row">
          <div class="col-lg-12 col-md-12 ">
            <div class="title-dashboard">
              <div class="title-dash flex2">Job Alerts</div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="flat-dashboard-dyagram flat-dashboard-password">
    <div class="box-notifications bg-white">
                <ul class="inner-box">
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4>Cooper</h4>
                    <p>applied for a job</p>
                    <a href="#" class="p-16 color-3"> UI Designer</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4>Simmons</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3"> UX Architect</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Richards</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3"> Internet Security </a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Russell</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3"> Developer</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Wilson</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3"> Developer</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Miles</h4>
                    <p>applied for a job</p>
                    <a href="#" class="p-16 color-3"> WordPress</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Webb</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3">PHP Developer</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Webb</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3">PHP Developer</a>
                  </li>
                  <li class="inner">
                    <a class="noti-icon"><span class="icon-bell1"></span></a>
                    <h4> Webb</h4>
                    <p>get a job</p>
                    <a href="#" class="p-16 color-3">PHP Developer</a>
                  </li>
                </ul>
              </div>
    </section>
    </div>
    </div>
  )
}
